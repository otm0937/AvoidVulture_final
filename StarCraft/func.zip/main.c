#include "header.h"
#include "terran.h"
#include "UI.h"
#define MAX_X 4096
#define MAX_Y 4096
int xx[16] = { -1,-1,-1,1,1,1,0,0 , -2,-2,-2,2,2,2,0,0};
int yy[16] = { -1,0,1,-1,0,1,-1,1,-1,0,1,-1,0,1,-2,2};




void scroll(int xScroll, int yScroll)	//���� ��ũ���ϴ� �Լ��̴�(��ü �ʿ��� ���� ��ġ�� �ٲ��ش�).
{
	scroll_X += xScroll * 17;
	scroll_Y += yScroll * 16;
	if (scroll_X < 0)
		scroll_X = 0;
	if (scroll_X > mapPixelSize - graphicWidth)
		scroll_X = mapPixelSize - graphicWidth;

	if (scroll_Y < 0)
		scroll_Y = 0;
	if (scroll_Y > mapPixelSize - graphicHeight)
		scroll_Y = mapPixelSize - graphicHeight;
}

void gotoMap()
{
	if (GDImouse_X <= 10)
		GDImouse_X = 10;
	if (GDImouse_X >= 118)
		GDImouse_X = 118;
	if (GDImouse_Y <= graphicHeight - 121)
		GDImouse_Y = graphicHeight - 121;
	if (GDImouse_Y >= graphicHeight - 8)
		GDImouse_Y = graphicHeight - 8;
	scroll_X = (GDImouse_X - 10) * 32;
	scroll_Y = (GDImouse_Y - graphicHeight + 121) * 32;
}

void processInput()
{
	if (GetAsyncKeyState(VK_LEFT) < 0 || mouse_X < 1)
		scroll(-1, 0);
	if (GetAsyncKeyState(VK_RIGHT) < 0 || mouse_X > pixelWidth - 2)
		scroll(1, 0);
	if (GetAsyncKeyState(VK_UP) < 0 || mouse_Y < 1)
		scroll(0, -1);
	if (GetAsyncKeyState(VK_DOWN) < 0 || mouse_Y > pixelHeight - 2)
		scroll(0, 1);
	if (GetAsyncKeyState(VK_LBUTTON) < 0) {
		mouseMode = drag;
		click++;
		if (GDImouse_X >= 0 && GDImouse_X <= 0 + 128 && GDImouse_Y >= graphicHeight - 128 && GDImouse_Y <= graphicHeight)
		{
			printf("map\n");
			gotoMap();
		}
		else if (click == 1) {
			start_x = GDImouse_X + scroll_X;
			start_y = GDImouse_Y + scroll_Y;
		}
		printf("   ");
	}
	else if (abs(start_x - GDImouse_X - scroll_X) < 15 && abs(start_y - GDImouse_Y - scroll_Y) < 15 && click>0) {
		int c = 0;
		for (int i = 0; i < Unitcnt; i++) {
			if (Units[i].x - Units[i].sizeX / 2 - 5 < GDImouse_X + scroll_X && Units[i].x + Units[i].sizeX / 2 + 5 > GDImouse_X + scroll_X && Units[i].y - Units[i].sizeY / 2 - 5 < GDImouse_Y + scroll_Y && Units[i].y + Units[i].sizeY / 2 + 5 > GDImouse_Y + scroll_Y) {
				if (c == 0) {
					for (int aa = 0; aa < Unitcnt; aa++)   Units[aa].selected = 0;
				}
				Units[i].selected = 1;
				c = 1;
			}
		}
		click = 0;
		c = 0;
	}
	else if (click > 0)
	{
		int mid_X = (start_x + GDImouse_X + scroll_X) / 2;
		int mid_Y = (start_y + GDImouse_Y + scroll_Y) / 2;
		int dis_X = abs(mid_X - start_x);
		int dis_Y = abs(mid_Y - start_y);
		int c = 0;
		for (int i = 0; i < Unitcnt; i++) {

			if (mid_X - dis_X < Units[i].x+10 && mid_X + dis_X > Units[i].x-10 && mid_Y - dis_Y < Units[i].y+10 && mid_Y + dis_Y > Units[i].y-10) {
				Units[i].selected = 0;
				if (c == 0) {
					for (int aa = 0; aa < Unitcnt; aa++)   Units[aa].selected = 0;
				}
				Units[i].selected = 1;
				c = 1;
			}
		}
		//gotoxy(0, 30);
		//printf("sx : %4d, sy : %4d\ndis : %4d, %4d\nmid : %4d %4d\n", start_x, start_y, dis_X, dis_Y, mid_X, mid_Y);
		click = 0;
		c = 0;
	}

	if (GetAsyncKeyState(VK_RBUTTON) < 0) {
		int prev = -1, destx = 0, desty = 0;
		int prevnum = 0;
		for (int i = 0; i < Unitcnt; i++) {
			if (Units[i].selected == 1&&Units[i].temp==0) {
				Units[i].temp = 1;
				Units[i].moving = 1;
				Units[i].moveStep = 1;
				if (1) {
					initMove(Units[i].x, Units[i].y, scroll_X + GDImouse_X, scroll_Y + GDImouse_Y, i);
					destx = scroll_X + GDImouse_X, desty = scroll_Y + GDImouse_Y;
					Units[i].destX = destx, Units[i].destY = desty;
				}
				prev = i;
				prevnum++; // �̵� ��ġ (�δ�����)
			}
		}
	}
	else {
		for (int i = 0; i < Unitcnt; i++) {
			Units[i].temp = 0;
		}
	}
}

DWORD __stdcall mouseInput(void *param)
{
	HWND hWnd = *(HWND*)param;
	POINT p;
	while (1)
	{
		GetCursorPos(&p);
		ScreenToClient(hWnd, &p);

		mouse_X = p.x;
		mouse_Y = p.y;
		GDImouse_X = (mouse_X - HorizonBorder)* 640 / (pixelWidth - HorizonBorder * 2) ;
		GDImouse_Y = (mouse_Y - VerticalBorder) * 480/ (pixelHeight - VerticalBorder * 2) ;
	}
}


int createUnit(int name,int x,int y) {
	for (int i = 0; i < Unitcnt; i++) {
		if (Units[i].isUsed == 0) {
			switch (name) {
			case SCV: Units[i] = SCVUnit;
			break; case Marine: Units[i] = MarineUnit;
			break; case Firebat: Units[i] = FirebatUnit;
			break; case Ghost: Units[i] = GhostUnit;
			break; case Medic: Units[i] = MedicUnit;
			break; case Vulture: Units[i] = VultureUnit;
			break; case SiegeTank: Units[i] = SiegeTankUnit;
			break; case Goliath: Units[i] = GoliathUnit;
			break; case Wraith: Units[i] = WraithUnit;
			break; case Dropship: Units[i] = DropshipUnit;
			break; case BattleCruiser: Units[i] = BattleCruiserUnit;
			break; case Valkyrie: Units[i] = ValkyrieUnit;
			break; case ScienceVessel: Units[i] = ScienceVesselUnit;
				break;
			}
			Units[i].isUsed = 1;
			Units[i].x = x;
			Units[i].y = y;
			return 0;
		}
	}
	return -1;
}



void printInfo()
{
	gotoxy(0, 0);
	printf("scroll_x =%5d\nscroll_y =%5d\n", scroll_X, scroll_Y);
	printf("1_x = %5d\n1_y = %5d\n", Units[0].x, Units[0].y);
	printf("2_x = %5d\n2_y = %5d\n", Units[1].x, Units[1].y);
	printf("x = %5d\ny = %5d\n", scroll_X + graphicWidth, scroll_Y + graphicHeight);
	printf("inmap1 = %d\n", Units[0].inMap);
	printf("inmap2 = %d\n", Units[1].inMap);
	printf("mouse_X = %5d\nmouse_Y = %5d\n", mouse_X, mouse_Y);
	printf("GDImouse_X = %5d\nGDImouse_Y = %5d\n", GDImouse_X, GDImouse_Y);
	printf("pixel = %5d %5d\n", pixelWidth, pixelHeight);
	printf("bordor = %5d %5d\n", HorizonBorder, VerticalBorder);
	printf("Units[0].selected = %d\n", Units[0].selected);
	printf("Units[0].x=%d, y = %d\n", Units[0].x, Units[0].y);
	printf("click : %3d\n", click);
	printf("selnum : %3d\n", selected);
}

void initxy() {
	for (int i = 0; i < Unitcnt; i++) {
		if (Units[i].isUsed == 0) {
			Units[i].x = -9999;
			Units[i].y = -9999;
		}
	}
}


typedef struct List {
	int f;
	int g;
	int h;
	int parent_idx;
	int x, y;
	int idx;
}list;

list closed[MAX_X*MAX_Y];
list opened[MAX_X*MAX_Y];

// �ּڰ� f�� ���������� ������� (push)
void swapList(int idx) {
	list temp;
	temp = opened[o - 1];
	opened[o - 1] = opened[idx];
	opened[idx] = temp;
}
//x,y�� ��ǥ���� closed�� �ִ��� ���� �Լ�
int isClosed(int x, int y) {
	for (int i = 0; i < c; i++) {
		if (x == closed[i].x&&y == closed[i].y) return 1;
	}
	return 0;
}
//Opened�� x,y��ǥ�� �ִ��� Ȯ�� - ������ �ε����� ����
int isOpened(int x, int y) {
	for (int i = 0; i < o; i++) {
		if (x == opened[i].x&&y == opened[i].y) return i;
	}
	return 0;
}
// �� ��庰�� ���� ��� �����ֱ� (a*)
void openList(int x, int y, int destx, int desty,int uidx) {
	int min = 99999999;
	int min_idx = -1;
	int outcont = 0;
	for (int i = 0; i < 8; i++) {
		if (x + xx[i] <= 0 || x + xx[i] > MAX_X || y + yy[i] <= 0 || y + yy[i] > MAX_Y)    continue;	//�迭 �Ѿ�°� ������
		for (int Y = -Units[uidx].sizeY / 2; Y < Units[uidx].sizeY / 2; Y++) {
			for (int X = -Units[uidx].sizeX / 2; X < Units[uidx].sizeX / 2; X++) {
				if (x + X + xx[i] <= 0 || y + Y + yy[i] <= 0 || x + X + xx[i] >= 4096 || y + Y + yy[i] >= 4096)	continue;
				if (fullMap[x + X + xx[i]][y + Y + yy[i]] == 1 || fullMap[x + X + xx[i]][y + Y + yy[i]] == 3) {
					outcont = 1;
					break;
				}
			}
			if (outcont == 1)
				break;
		}
		if (outcont == 1) {
			outcont = 0;
			continue;
		}
		if (fullMap[x + xx[i]][y + yy[i]] != 3 && fullMap[x + xx[i]][y + yy[i]] != 1 && !isClosed(x + xx[i], y + yy[i])) {

			int idx = isOpened(x + xx[i], y + yy[i]);
			if (idx != 0 && opened[idx].g > closed[c - 1].g + ((i == 0 || i == 2 || i == 3 || i == 5) ? 14 : 10)) {
				opened[idx].parent_idx = closed[c - 1].idx;
				opened[idx].g = closed[c - 1].g + ((i == 0 || i == 2 || i == 3 || i == 5) ? 14 : 10);
				opened[idx].g += (i == 0 || i == 2 || i == 3 || i == 5) ? 14 : 10;
				opened[idx].h = (abs(destx - x - xx[i]) + abs(desty - y + yy[i])) * 10;
				opened[idx].f = opened[idx].g + opened[idx].h;
			}
			else if (idx == 0) {
				opened[o].idx = k++;
				opened[o].parent_idx = closed[c - 1].idx;
				opened[o].g = (i == 0 || i == 2 || i == 3 || i == 5) ? 14 + closed[opened[o].parent_idx].g : 10 + closed[opened[o].parent_idx].g;
				opened[o].h = (abs(destx - x - xx[i]) + abs(desty - y - yy[i])) * 10;
				opened[o].f = opened[o].g + opened[o].h;
				opened[o].x = x + xx[i];
				opened[o].y = y + yy[i];
				o++;
			}
		}
	}
	for (int i = 0; i < o; i++) {
		if (min > opened[i].f) {
			min = opened[i].f;
			min_idx = i;
		}
	}
	if (min_idx != o - 1)   swapList(min_idx);
}
//a* �˰��������� ��� ã��
int searchPath(int x, int y, int destx, int desty, int idx) {
	while (1) {
		if (closed[c - 1].x == destx && closed[c - 1].y == desty) return 1;	//�����ϸ� return 1;
		if (o < 0)    return 0;	//�����ִ� ��尡 ������ return 0;
		if (o >= 3000)	return 0;
		if (c >= 3000)	return 0;
		openList(x, y, destx, desty, idx);

		closed[c++] = opened[o - 1];	//�ּ� ��� closed�� �߰�

		x = closed[c - 1].x, y = closed[c - 1].y;
		o--;	//push;
	}
}

//searchPath�� ���� route�� �θ� ���� ã�ư��� ��� ã��
void findPath(int x, int y, int idx) {
	k = 0;
	int p_idx = 0;
	Units[idx].moveStep = 0;
	for (int i = c - 1; i >= 0; i--) {
		if (i == c - 1) {
			Units[idx].route[k][0] = closed[i].x;
			Units[idx].route[k][1] = closed[i].y;
			p_idx = closed[i].parent_idx;
			k++;
			Units[idx].moveStep++;
		}
		else if (closed[i].idx == p_idx) {
			Units[idx].route[k][0] = closed[i].x;
			Units[idx].route[k][1] = closed[i].y;
			p_idx = closed[i].parent_idx;
			k++;
			Units[idx].moveStep++;
		}
	}
}


//�ʱⰪ ����
void initClosed(int x, int y) {
	list blank = { 0 };
	for (int i = 0; i < 8000; i++) {
		closed[i] = blank;
	}
	for (int i = 0; i < 8000; i++) {
		opened[i] = blank;
	}
	closed[c].x = x;
	closed[c].y = y;
	closed[c].idx = c;
	closed[c].parent_idx = -1;
	c++;
}
int initMove(int x, int y, int destx, int desty, int idx) {

	for (int y = -Units[idx].sizeY / 2; y < Units[idx].sizeY / 2; y++) {
		for (int x = -Units[idx].sizeX / 2; x < Units[idx].sizeX / 2; x++) {
			if (Units[idx].x + x <= 0 || Units[idx].y + y <= 0 || Units[idx].x + x >= 4096 || Units[idx].y + y >= 4096)	continue;
			fullMap[Units[idx].x + x][Units[idx].y + y] = 0;
		}
	}

	while (fullMap[destx][desty]==1) {
		if (destx > 100 && desty > 100) {
			if (rand() % 100 >= 50)	destx--;
			else	desty--;
		}
		else  if (destx < 1000 && desty<1000){
			if (rand() % 100 >= 50)	destx++;
			else	desty++;
		}
	}
	o = 0, c = 0, k = 1; //o : opened ����, c = closed ����
	for (int y = -Units[idx].sizeY / 2; y < Units[idx].sizeY / 2; y++) {
		for (int x = -Units[idx].sizeX / 2; x < Units[idx].sizeX / 2; x++) {
			if (Units[idx].x + x <= 0 || Units[idx].y + y <= 0 || Units[idx].x + x >= 4096 || Units[idx].y + y >= 4096)	continue;
			fullMap[Units[idx].x + x][Units[idx].y + y] = 0;
		}
	}
	initClosed(x, y);
	if (searchPath(x, y, destx, desty,idx)) {
		findPath(x, y, idx);
	}
	else {
		gotoxy(0, 40);
		printf("noooooooooooo\n");
		Units[idx].moving = 0;
	}
	for (int y = -Units[idx].sizeY / 2; y < Units[idx].sizeY / 2; y++) {
		for (int x = -Units[idx].sizeX / 2; x < Units[idx].sizeX / 2; x++) {
			if (Units[idx].x + x <= 0 || Units[idx].y + y <= 0 || Units[idx].x + x >= 4096 || Units[idx].y + y >= 4096)	continue;
			fullMap[Units[idx].x + x][Units[idx].y + y] = 1;
		}
	}
}

int collisionCheck(int i) {
	for (int y = -Units[i].sizeY / 2; y < Units[i].sizeY / 2; y++) {
		for (int x = -Units[i].sizeX / 2; x < Units[i].sizeX / 2; x++) {
			if (Units[i].x + x <= 0 || Units[i].y + y <= 0 || Units[i].x + x >= 4096 || Units[i].y + y >= 4096)	continue;
			fullMap[Units[i].x + x][Units[i].y + y] = 0;
		}
	}
	int a = Units[i].route[Units[i].moveStep - 1][0];
	int b = Units[i].route[Units[i].moveStep - 1][1];
	for (int y = -Units[i].sizeY / 2; y < Units[i].sizeY / 2; y++) {
		for (int x = -Units[i].sizeX / 2; x < Units[i].sizeX / 2; x++) {
			if (a + x <= 0 || b + y <= 0 || a + x >= 4096 || b + y >= 4096)	continue;
			if (fullMap[a + x][b + y] == 1) {
				for (int y = -Units[i].sizeY / 2; y < Units[i].sizeY / 2; y++) {
					for (int x = -Units[i].sizeX / 2; x < Units[i].sizeX / 2; x++) {
						if (Units[i].x + x <= 0 || Units[i].y + y <= 0 || Units[i].x + x >= 4096 || Units[i].y + y >= 4096)	continue;
						fullMap[Units[i].x + x][Units[i].y + y] = 1;
					}
				}
				return 1;
			}
		}
	}
	for (int y = -Units[i].sizeY / 2; y < Units[i].sizeY / 2; y++) {
		for (int x = -Units[i].sizeX / 2; x < Units[i].sizeX / 2; x++) {
			if (Units[i].x + x <= 0 || Units[i].y + y <= 0 || Units[i].x + x >= 4096 || Units[i].y + y >= 4096)	continue;
			fullMap[Units[i].x + x][Units[i].y + y] = 1;
		}
	}
	return 0;
}

int checkDirection(int x, int y, int destx, int desty) {
	double g = (double)(desty - y) / (double)(destx - x); // g : ����
	g *= -1;
	if (destx == x) {
		if (desty > y)	return 16;
		else	return 0;
	}
	else if (-0.125000 <= g && g <= 0.125000)            return (destx > x ? 8 : 24);
	else if (-0.125000 >= g && g >= -0.375000)    return (destx > x ? 9 : 25);
	else if (-0.375000 >= g && g >= -0.625000)    return (destx > x ? 10 : 26);
	else if (-0.625000 >= g && g >= -0.875000)    return (destx > x ? 11 : 27);
	else if (-0.875000 >= g && g >= -1.143000)    return (destx > x ? 12 : 28);
	else if (-1.143000 >= g && g >= -1.600000)    return (destx > x ? 13 : 29);
	else if (-1.600000 >= g && g >= -2.667000)    return (destx > x ? 14 : 30);
	else if (-2.667000 >= g && g >= -8.000000)    return (destx > x ? 15 : 31);
	else if (8 <= g || g < -8)                    return (desty > y ? 16 : 0);
	else if (2.667000 <= g && g <= 8.000000)        return (destx > x ? 1 : 17);
	else if (1.600000 <= g && g <= 2.667000)        return (destx > x ? 2 : 18);
	else if (1.143000 <= g && g <= 1.600000)        return (destx > x ? 3 : 19);
	else if (0.875000 <= g && g <= 1.143000)        return (destx > x ? 4 : 20);
	else if (0.625000 <= g && g <= 0.875000)        return (destx > x ? 5 : 21);
	else if (0.375000 <= g && g <= 0.625000)        return (destx > x ? 6 : 22);
	else if (0.125000 <= g && g <= 0.375000)        return (destx > x ? 7 : 23);
	else {
		printf("\n%lf\n", g);
	}
}

void move() {
	gotoxy(0, 35);
	int ex = 0;
	int outbreak = 0;
	printf("k : %3d\n", Units[0].moveStep);
	for (int i = 0; i < Unitcnt; i++) {
		if (Units[i].moving == 1) {
			if (collisionCheck(i) == 1) {
				if (Units[i].wait >= 50) {
					Units[i].wait = 0;
					initMove(Units[i].x, Units[i].y, Units[i].destX, Units[i].destY,i);
				}
				Units[i].wait++;
				continue;
			}
			else {
				Units[i].direction = checkDirection(Units[i].x, Units[i].y, Units[i].route[Units[i].moveStep - 1][0], Units[i].route[Units[i].moveStep - 1][1]) / 2 * 2;
				for (int y = -Units[i].sizeY / 2; y < Units[i].sizeY / 2; y++) {
					for (int x = -Units[i].sizeX / 2; x < Units[i].sizeX / 2; x++) {
						if (Units[i].x + x <= 0 || Units[i].y + y <= 0 || Units[i].x + x >= 4096 || Units[i].y + y >= 4096)	continue;
						fullMap[Units[i].x + x][Units[i].y + y] = 0;
					}
				}
				if (Units[i].moveStep == 0) {
					Units[i].moving = 0;
					continue;
				}


				else {
					Units[i].wait = 0;
					for (int a = 1; a < Units[i].moveStep; a++) {
						//	printf("%d %d\n", Units[i].route[a][0], Units[i].route[a][1]);
					}
					//system("pause");
					Units[i].x = Units[i].route[Units[i].moveStep - 1][0];
					Units[i].y = Units[i].route[Units[i].moveStep - 1][1];
					Units[i].moveStep--;
				}
				for (int y = -Units[i].sizeY / 2; y < Units[i].sizeY / 2; y++) {
					for (int x = -Units[i].sizeX / 2; x < Units[i].sizeX / 2; x++) {
						if (Units[i].x + x <= 0 || Units[i].y + y <= 0 || Units[i].x + x >= 4096 || Units[i].y + y >= 4096)	continue;
						fullMap[Units[i].x + x][Units[i].y + y] = 1;
					}
				}
			}
			
		}
	}
}

void initwait() {
	for (int i = 0; i < Unitcnt; i++) {
		Units[i].wait = 0;
	}
}


int main() {
	
	srand(time(0));
	HWND hWnd = getConsoleWindowHandle();

	dpi = GetDPI(hWnd);
	paint(hWnd);
	CreateThread(NULL, 8 * 1024 * 1024, mouseInput, &hWnd, NULL, NULL);
	fullscreenConsole();
	imgLoad();
	mouseMode = arrow;
	HANDLE CIN = GetStdHandle(STD_INPUT_HANDLE);
	DWORD mode;
	GetConsoleMode(CIN, &mode);
	SetConsoleMode(CIN, mode | ENABLE_MOUSE_INPUT);
	for (int n = 1; n <=1 ;)
	{
		for (int i = 1; i <= 10; i++) {
			for (int j = 1; j <= 10; j++) {
				createUnit(Marine, i * 100, j * 100);
				n++;
			}
		}
	}
	initwait();
	while (1)
	{
		move();
		initxy();
		initCursor();
		inMapCheck();
		processInput();
		printInfo();
		long long oldTime = GetTickCount64();

		paint(hWnd);

		long long nowTime = GetTickCount64();

		printf("sleep = %3lldms\n", nowTime - oldTime);
		if (nowTime - oldTime < 16)
			Sleep(16 - (nowTime - oldTime));



		for (int i = 0; i < Unitcnt; i++)
		{
			if (Units[i].selected == 1)    continue;

		}
	}
}