#include "header.h"
#include "terran.h"
#include "UI.h"



void inMapCheck()
{
	int mousecheck = 0;
	for (int i = 0; i < mapSize; i++) {
		for (int j = 0; j < mapSize; j++) {
			map[i][j] = 0;
		}
	}
	for (int i = 0; i < 2096; i++) {
		for (int j = 0; j < 2096; j++) {
			fullMap[i][j] = 0;
		}
	}
	for (int i = 0; i < Unitcnt; i++)
	{
		if (!Units[i].isUsed)
			continue;
		if (Units[i].x > scroll_X - 200 && Units[i].x < scroll_X + graphicWidth + 200
			&& Units[i].y > scroll_Y - 200 && Units[i].y < scroll_Y + graphicHeight + 200)
			Units[i].inMap = 1;
		else
			Units[i].inMap = 0;
		map[Units[i].x / 32][Units[i].y / 32] = 1;
		
		if (Units[i].isUsed) {
			for (int y = -Units[i].sizeY / 2; y < Units[i].sizeY / 2; y++) {
				for (int x = -Units[i].sizeX / 2; x < Units[i].sizeX / 2; x++) {
					if (Units[i].x + x <= 0 || Units[i].y + y <= 0 || Units[i].x + x >= 4096 || Units[i].y + y >= 4096)	continue;
					fullMap[Units[i].x + x][Units[i].y + y] = 1;
				}
			}
		}

		if (Units[i].x - Units[i].sizeX / 2 <= GDImouse_X && Units[i].x + Units[i].sizeX / 2 >= GDImouse_X &&
			Units[i].y - Units[i].sizeY / 2 <= GDImouse_Y && Units[i].y + Units[i].sizeY / 2 >= GDImouse_Y)
			mousecheck = 1;
	}
	if (mousecheck == 1)
		mouseMode = magg;
	else
		mouseMode = arrow;
}


void paintUnits(unsigned int screen[graphicHeight][graphicWidth], unsigned int Unitimg[][bmpSize][bmpSize], int X, int Y, int direction) {
	for (int i = 0; i < bmpSize; i++) {
		if (0 <= i + Y - scroll_Y - (bmpSize / 2) && i + Y - scroll_Y - (bmpSize / 2) < graphicHeight)
			for (int j = 0; j < bmpSize; j++)
				if (direction > 16) {
					if (0 <= (bmpSize - 1) - j + X - scroll_X - (bmpSize / 2) && (bmpSize - 1) - j + X - scroll_X - (bmpSize / 2) < graphicWidth)
						if ((Unitimg[32 - direction][i][j] & 0xFFFFFF) != 0x0000ff)
							screen[i + Y - scroll_Y - (bmpSize / 2)][(bmpSize - 1) - j + X - scroll_X - (bmpSize / 2)] = Unitimg[32 - direction][i][j];
				}
				else {
					if (0 <= j + X - scroll_X - (bmpSize / 2) && j + X - scroll_X - (bmpSize / 2) < graphicWidth)
						if ((Unitimg[direction][i][j] & 0xFFFFFF) != 0x0000ff)
							screen[i + Y - scroll_Y - (bmpSize / 2)][j + X - scroll_X - (bmpSize / 2)] = Unitimg[direction][i][j];
				}
	}
}


void paintGroundUnits(unsigned int screen[graphicHeight][graphicWidth]) {
	for (int n = 0; n < Unitcnt; n++) {
		if (Units[n].isUsed&&Units[n].inMap) {
			switch (Units[n].name) {
			case SCV:
				paintUnits(screen, SCVimg, Units[n].x, Units[n].y, Units[n].direction);
			break; case Marine:
				paintUnits(screen, Marineimg, Units[n].x, Units[n].y, Units[n].direction);
			break; case Firebat:
				paintUnits(screen, Firebatimg, Units[n].x, Units[n].y, Units[n].direction);
			break; case Ghost:
				paintUnits(screen, Ghostimg, Units[n].x, Units[n].y, Units[n].direction);
			break; case Medic:
				paintUnits(screen, Medicimg, Units[n].x, Units[n].y, Units[n].direction);
			break; case Vulture:
				paintUnits(screen, Vultureimg, Units[n].x, Units[n].y, Units[n].direction);

			break; case SiegeTank:
				paintUnits(screen, SiegeTankimg, Units[n].x, Units[n].y, Units[n].direction);
				paintUnits(screen, SiegeTankTimg, Units[n].x, Units[n].y, Units[n].directionTurret);
			break; case SiegeTankS:
				paintUnits(screen, SiegeTankSimg, Units[n].x, Units[n].y, Units[n].direction);
				paintUnits(screen, SiegeTankSTimg, Units[n].x, Units[n].y, Units[n].directionTurret);
			break; case Goliath:
				paintUnits(screen, Goliathimg, Units[n].x, Units[n].y, Units[n].direction);
				paintUnits(screen, GoliathTimg, Units[n].x, Units[n].y, Units[n].directionTurret);


			break; case Wraith:
				paintUnits(screen, Wraithimg, Units[n].x, Units[n].y, Units[n].direction);
			break; case Dropship:
				paintUnits(screen, Dropshipimg, Units[n].x, Units[n].y, Units[n].direction);
			break; case BattleCruiser:
				paintUnits(screen, BattleCruiserimg, Units[n].x, Units[n].y, Units[n].direction);
			break; case Valkyrie:
				paintUnits(screen, Valkyrieimg, Units[n].x, Units[n].y, Units[n].direction);


			break; case ScienceVessel:
				paintUnits(screen, ScienceVesselimg, Units[n].x, Units[n].y, Units[n].direction);
				paintUnits(screen, ScienceVesselTimg, Units[n].x, Units[n].y, Units[n].directionTurret);
				break;
			}
		}
	}
}





void paintMap(unsigned int screen[graphicHeight][graphicWidth]) {
	for (int i = 0; i < mapSize; i++)
	{
		for (int j = 0; j < mapSize; j++)
		{
			if (map[j][i] == 1)
				screen[i + graphicHeight - 128][j] = 0x00ff00; //���� ��ġ �ʷϻ�
			else
				screen[i + graphicHeight - 128][j] = 0x000000; //����� ������
			if ((j == scroll_X / 32 || j == (scroll_X + graphicWidth) / 32 - 1) && i >= scroll_Y / 32 && i <= (scroll_Y + graphicHeight) / 32 - 1 ||
				(i == scroll_Y / 32 || i == (scroll_Y + graphicHeight) / 32 - 1) && j >= scroll_X / 32 && j <= (scroll_X + graphicWidth) / 32 - 1)
				screen[i + graphicHeight - 128][j] = 0xffffff; //���� �� �Ͼ�� �簢��

		}
	}
	for (int i = 0; i < mapSize + 1; i++)
	{
		screen[graphicHeight - 129][i] = 0xffffff;
	}
	for (int i = 0; i < mapSize + 1; i++)
	{
		screen[i + graphicHeight - 129][129] = 0xffffff;
	}
}


void cursors(unsigned int screen[graphicHeight][graphicWidth], unsigned int mouseimg[][bmpSize][bmpSize]) {
	for (int i = 0; i < bmpSize; i++)
		if (0 <= i + GDImouse_Y - (bmpSize / 2) && i + GDImouse_Y - (bmpSize / 2) < graphicHeight)
			for (int j = 0; j < bmpSize; j++)
				if (0 <= j + GDImouse_X - (bmpSize / 2) && j + GDImouse_X - (bmpSize / 2) < graphicWidth)
					if ((mouseimg[mouseLoop][i][j] & 0xFFFFFF) != 0x0000ff)
						screen[i + GDImouse_Y - (bmpSize / 2)][j + GDImouse_X - (bmpSize / 2)] = (mouseimg[mouseLoop][i][j]);
	mouseLoop++;
}

void paintMouseCursor(unsigned int screen[graphicHeight][graphicWidth]) {
	
	switch (mouseMode) {
	case arrow:				if (mouseLoop >= arrowImgCount)		mouseLoop = 0; cursors(screen, arrowimg);
	break; case drag:		if (mouseLoop >= dragImgCount)		mouseLoop = 0; cursors(screen, dragimg);
	break; case magg:		if (mouseLoop >= maggImgCount)		mouseLoop = 0; cursors(screen, maggimg);
	break; case magr:		if (mouseLoop >= magrImgCount)		mouseLoop = 0; cursors(screen, magrimg);
	break; case magy:		if (mouseLoop >= magyImgCount)		mouseLoop = 0; cursors(screen, magyimg);

	break; case scrolld:	if (mouseLoop >= scrolldImgCount)	mouseLoop = 0; cursors(screen, scrolldimg);
	break; case scrolldl:	if (mouseLoop >= scrolldlImgCount)	mouseLoop = 0; cursors(screen, scrolldlimg);
	break; case scrolldr:	if (mouseLoop >= scrolldrImgCount)	mouseLoop = 0; cursors(screen, scrolldrimg);
	break; case scrolll:	if (mouseLoop >= scrolllImgCount)	mouseLoop = 0; cursors(screen, scrolllimg);
	break; case scrollr:	if (mouseLoop >= scrollrImgCount)	mouseLoop = 0; cursors(screen, scrollrimg);
	break; case scrollu:	if (mouseLoop >= scrolluImgCount)	mouseLoop = 0; cursors(screen, scrolluimg);
	break; case scrollul:	if (mouseLoop >= scrollulImgCount)	mouseLoop = 0; cursors(screen, scrollulimg);
	break; case scrollur:	if (mouseLoop >= scrollurImgCount)	mouseLoop = 0; cursors(screen, scrollurimg);

	break; case targg:		if (mouseLoop >= targgImgCount)		mouseLoop = 0; cursors(screen, targgimg);
	break; case targr:		if (mouseLoop >= targrImgCount)		mouseLoop = 0; cursors(screen, targrimg);
	break; case targy:		if (mouseLoop >= targyImgCount)		mouseLoop = 0; cursors(screen, targyimg);
	break; case targn:		if (mouseLoop >= targnImgCount)		mouseLoop = 0; cursors(screen, targnimg);
	break;
	}
}


void paintDrag(unsigned int screen[graphicHeight][graphicWidth], int dis_X, int dis_Y, int mid_X, int mid_Y) {
	gotoxy(0, 30);
	//printf("s_x,s_y : %d %d\n", start_x, start_y);
	//printf("mx ,my : %d %d\n", mid_X, mid_Y);
	//printf("dx, dy : %d %d\n", dis_X, dis_Y);
	for (int i = 0; i < graphicWidth; i++) {
		for (int j = 0; j < graphicHeight; j++) {
			if ((mid_X - dis_X <= i + scroll_X && mid_X + dis_X >= i + scroll_X && mid_Y + dis_Y == j + scroll_Y) || (mid_X - dis_X <= i + scroll_X && mid_X + dis_X >= i + scroll_X && mid_Y - dis_Y == j + scroll_Y) ||
				(mid_Y - dis_Y <= j + scroll_Y && mid_Y + dis_Y >= j + scroll_Y && mid_X + dis_X == i + scroll_X) || (mid_Y - dis_Y <= j + scroll_Y && mid_Y + dis_Y >= j + scroll_Y && mid_X - dis_X == i + scroll_X))
				screen[j][i] = 0x00ff00;
		}

	}
}


void DrawEllipse(unsigned int screen[graphicHeight][graphicWidth])
{
	int x, y, sigma;
	for (int i = 0; i < Unitcnt; i++) {
		if (Units[i].selected == 1) {
			int xc = Units[i].x, yc = Units[i].y, width = Units[i].sizeX / 3 * 2, height = width / 4 * 3;
			int a2 = width * width;
			int b2 = height * height;
			int fa2 = 4 * a2, fb2 = 4 * b2;
			/* first half */
			for (x = 0, y = height, sigma = 2 * b2 + a2 * (1 - 2 * height); b2*x <= a2 * y; x++)
			{
				if (yc - y + 10 - scroll_Y > 0 && yc + y + 10 - scroll_Y < graphicHeight && xc - x - scroll_X > 0 && xc + x - scroll_X < graphicWidth)
				{
					screen[yc + y + 10 - scroll_Y][xc + x - scroll_X] = 0x00ff00;
					screen[yc + y + 10 - scroll_Y][xc - x - scroll_X] = 0x00ff00;
					screen[yc - y + 10 - scroll_Y][xc + x - scroll_X] = 0x00ff00;
					screen[yc - y + 10 - scroll_Y][xc - x - scroll_X] = 0x00ff00;
				}
				if (sigma >= 0)
				{
					sigma += fa2 * (1 - y);
					y--;
				}
				sigma += b2 * ((4 * x) + 6);
			}

			/* second half */
			for (x = width, y = 0, sigma = 2 * a2 + b2 * (1 - 2 * width); a2*y <= b2 * x; y++)
			{
				if (yc - y + 10 - scroll_Y >= 0 && yc + y + 10 - scroll_Y < graphicHeight && xc - x - scroll_X >= 0 && xc + x - scroll_X < graphicWidth)
				{
					screen[yc + y + 10 - scroll_Y][xc + x - scroll_X] = 0x00ff00;
					screen[yc + y + 10 - scroll_Y][xc - x - scroll_X] = 0x00ff00;
					screen[yc - y + 10 - scroll_Y][xc + x - scroll_X] = 0x00ff00;
					screen[yc - y + 10 - scroll_Y][xc - x - scroll_X] = 0x00ff00;
				}
				if (sigma >= 0)
				{
					sigma += fb2 * (1 - x);
					x--;
				}
				sigma += a2 * ((4 * y) + 6);
			}
		}
	}

}



void paint(HWND hWnd) {
	RECT screen;
	GetClientRect(hWnd, &screen);
	pixelWidth = screen.right - screen.left;
	pixelHeight = screen.bottom - screen.top;
	screen.top = screen.top * dpi / 96;
	screen.bottom = screen.bottom * dpi / 96;
	screen.left = screen.left * dpi / 96;
	screen.right = screen.right * dpi / 96;

	int screenWidth;
	int screenHeight;
	int consoleWidth = screen.right - screen.left;
	int consoleHeight = screen.bottom - screen.top;
	int a = consoleHeight * 4 / 3;
	int b = consoleWidth * 3 / 4;





	if (a < screen.right - screen.left)
	{
		screenWidth = a;
		screenHeight = screen.bottom - screen.top;
	}
	else
	{
		screenWidth = screen.right - screen.left;
		screenHeight = b;
	}
	printf("console %5d %5d\nscreen %5d %5d\n", consoleWidth, consoleHeight, screenWidth, screenHeight);
	HorizonBorder = (consoleWidth - screenWidth) * 96 / dpi / 2;
	VerticalBorder = (consoleHeight - screenHeight) * 96 / dpi / 2;

	HDC hdc = GetDC(hWnd);

	BITMAPINFOHEADER bitmapinfo;
	bitmapinfo.biSize = sizeof(BITMAPINFO);
	bitmapinfo.biHeight = -graphicHeight;
	bitmapinfo.biWidth = graphicWidth;
	bitmapinfo.biPlanes = 1;
	bitmapinfo.biBitCount = 32;
	bitmapinfo.biCompression = BI_RGB;
	void *img;

	HBITMAP hbitmap = CreateDIBSection(hdc, &bitmapinfo, DIB_RGB_COLORS, &img, NULL, 0);
	HDC memdc = CreateCompatibleDC(hdc);
	SelectObject(memdc, hbitmap);


	DrawEllipse(img);
	paintGroundUnits(img);
	paintMap(img);
	if (click > 1)
	{
		paintDrag(img, abs(start_x - ((start_x + GDImouse_X + scroll_X) / 2)),
			abs(start_y - ((start_y + GDImouse_Y + scroll_Y) / 2)),
			(start_x + GDImouse_X + scroll_X) / 2,
			(start_y + GDImouse_Y + scroll_Y) / 2);
	}
	paintMouseCursor(img);





	//SetStretchBltMode(hdc, HALFTONE); ���� ó��
	//SetBrushOrgEx(hdc, 0, 0, NULL);
	StretchBlt(hdc, (consoleWidth - screenWidth) / 2, (consoleHeight - screenHeight) / 2, screenWidth, screenHeight, memdc, 0, 0, graphicWidth, graphicHeight, SRCCOPY);

	DeleteDC(memdc);
	DeleteObject(hbitmap);
	ReleaseDC(hWnd, hdc);
}